/*
 * LightDriveCAN.h
 *
 *  Created on: Sep 14, 2017
 *      Author: Mike
 */

#ifndef SRC_LIGHTDRIVECAN_H_
#define SRC_LIGHTDRIVECAN_H_

class LightDriveCAN
{

	public:

		typedef struct {
			uint8_t red;
			uint8_t green;
			uint8_t blue;
		} Color;

		// Mode: 0-No Signal. 1-PWM. 2-CAN. 3-Serial.
		typedef union {
			struct {
			uint8_t Enabled			:1;
			uint8_t Mode			:3;
			uint8_t Bank1_Trip		:1;
			uint8_t Bank2_Trip		:1;
			uint8_t Bank3_Trip		:1;
			uint8_t Bank4_Trip		:1;
			};
			uint8_t Raw;
		} Status;

		//Pre-defined colors
		struct Colors {
			//R-G-B
			constexpr static Color RED{255,0,0};
			constexpr static Color GREEN{0,255,0};
			constexpr static Color BLUE{0,0,255};
			constexpr static Color TEAL{0,200,255};
			constexpr static Color YELLOW{255,200,0};
			constexpr static Color PURPLE{255,0,255};
			constexpr static Color PINK{255,0,200};
			constexpr static Color ORANGE{255,50,0};
			constexpr static Color WHITE{255,255,255};
			constexpr static Color OFF{0,0,0};
		};

		//Constructor
		LightDriveCAN();
		//Constructor for multiple LightDrives (unimplemented)
		LightDriveCAN(int addr);

		// Call this function whenever an update is desired
		void Update();

		// Return current of a bank of channels (1-4) in A
		float GetCurrent(uint8_t ch);
		// Return total board current in A
		float GetTotalCurrent();
		// Return input voltage in V
		float GetVoltage();
		// Returns LightDrive firmware version
		int16_t GetFWVersion();
		// Returns status flags
		Status GetStatus();
		// Returns PWM input value (0-255) on given channel (1-2).
		int16_t GetPWMs(uint8_t ch);

		//Set given Color on given bank (1-4). Updates on next Update()
		void SetColor(int ch, LightDriveCAN::Color color);
		//Set given Color on given bank (1-4) to given brightness. Updates on next Update()
		void SetColor(int ch, LightDriveCAN::Color color, float brightness);
		//Set Raw PWM value (0-255) on a given channel (1-12).
		void SetLevel(int ch, int level);

		//Return a Color type based on given RGB values (0-255)
		Color MakeColor(uint8_t r, uint8_t g, uint8_t b);

	private:
		typedef struct {
			uint8_t I1;
			uint8_t I2;
			uint8_t I3;
			uint8_t I4;
			uint8_t VIN;
			Status status;
			uint8_t PWMVals;
			uint8_t FW;
		} RxPacket;

		static const int LD_ADDR = 0x02050000;
		uint8_t m_matrix[16] = {};
		RxPacket m_rx = {};
		bool m_init = false;
		uint8_t data[8] = {};
};

#endif /* SRC_LIGHTDRIVECAN_H_ */
