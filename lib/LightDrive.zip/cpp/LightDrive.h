/*
 * LightDrive.h
 *
 *  Created on: Sep 13, 2017
 *      Author: Mike
 */

#ifndef SRC_LIGHTDRIVE_H_
#define SRC_LIGHTDRIVE_H_

class LightDrive
{

	public:

		typedef struct {
			uint8_t red;
			uint8_t green;
			uint8_t blue;
		} Color;

		//Pre-defined colors
		struct Colors {
			//R-G-B
			constexpr static Color RED{255,0,0};
			constexpr static Color GREEN{0,255,0};
			constexpr static Color BLUE{0,0,255};
			constexpr static Color TEAL{0,255,255};
			constexpr static Color YELLOW{255,255,0};
			constexpr static Color PURPLE{255,0,255};
			constexpr static Color WHITE{255,255,255};
			constexpr static Color OFF{0,0,0};
		};

		// Constructor. Provide a pointer to 2 configured Servo Classes to be used.
		LightDrive(Servo *s1, Servo *s2);

		// Updates the PWM output values when called
		void Update();

		//Set given Color on given bank (1-4). Updates on next Update()
		void SetColor(int ch, LightDrive::Color color);
		//Set given Color on given bank (1-4). Brightness ignored on PWM control. Updates on next Update()
		void SetColor(int ch, LightDrive::Color color, float brightness);
		//Set Raw PWM value (0-255) on a given channel (1-12).
		void SetLevel(int ch, int level);

		//Return a Color type based on given RGB values (0-255)
		Color MakeColor(uint8_t r, uint8_t g, uint8_t b);

	private:
		DigitalOutput *m_pwm_select;
		DigitalOutput *m_pwm_value;
		Servo *m_servo_select;
		Servo *m_servo_value;

		uint8_t m_matrix[12] = {};
		bool m_type_servo = false;

};

//static constexpr LightDrive::Color RED = {255,0,0};

#endif /* SRC_LIGHTDRIVE_H_ */
